/**
 * The PokemonGameTester class is used to test and run the game simulation.
 */
public class PokemonGameTester {
    public static void main(String[] args) {
        PokemonGame game = new PokemonGame();
        game.startGame();
    }
}
