/**
 * The EnergyCard class represents an Energy card.
 * Energy cards provide the power needed for Pokémon to perform attacks.
 */
public class EnergyCard implements Card {
    private String type;

    /**
     * Constructs an EnergyCard with the specified type.
     *
     * @param type the type of energy (e.g., "Electric", "Fire")
     */
    public EnergyCard(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return "Energy: " + type;
    }
}
