/**
 * A marker interface for all card types.
 */
public interface Card {
    // Future common methods for cards can be added here.
}
