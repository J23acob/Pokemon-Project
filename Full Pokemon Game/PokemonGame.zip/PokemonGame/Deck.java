import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * The Deck class represents a deck of cards for a player.
 * In our simplified version, each deck contains 60 cards:
 * 20 Pokémon, 20 Trainer, and 20 Energy cards.
 */
public class Deck {
    List<Card> cards; // remains package-private or private; we access it via methods.
    private Random rand;

    /**
     * Constructs a Deck with the provided list of cards.
     *
     * @param cards the list of cards to include in the deck.
     */
    public Deck(List<Card> cards) {
        this.cards = new ArrayList<>(cards);
        this.rand = new Random();
    }

    /**
     * Shuffles the deck randomly.
     */
    public void shuffle() {
        Collections.shuffle(cards, rand);
    }

    /**
     * Draws the top card from the deck.
     *
     * @return the drawn card, or null if the deck is empty.
     */
    public Card drawCard() {
        if (cards.isEmpty()) {
            return null;
        }
        return cards.remove(0);
    }

    /**
     * Draws multiple cards from the top of the deck.
     *
     * @param n number of cards to draw.
     * @return a list of drawn cards.
     */
    public List<Card> drawCards(int n) {
        List<Card> drawn = new ArrayList<>();
        for (int i = 0; i < n && !cards.isEmpty(); i++) {
            drawn.add(drawCard());
        }
        return drawn;
    }

    /**
     * Adds a card to the bottom of the deck.
     *
     * @param card the card to add.
     */
    public void addCard(Card card) {
        cards.add(card);
    }

    /**
     * Returns the number of cards remaining in the deck.
     *
     * @return the number of remaining cards.
     */
    public int remainingCards() {
        return cards.size();
    }
}
