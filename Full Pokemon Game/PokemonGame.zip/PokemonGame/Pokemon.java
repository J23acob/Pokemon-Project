import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Pokemon implements Card {
    private String name;
    private String type;  // e.g., Fire, Grass, Water
    private int hp;
    private int maxHP;
    private List<Attack> attacks;
    private List<String> attachedEnergies;  // List of attached energy types

    public Pokemon(String name, String type, int hp, List<Attack> attacks) {
        this.name = name;
        this.type = type;
        this.hp = hp;
        this.maxHP = hp; // Set maxHP to initial HP.
        this.attacks = attacks;
        this.attachedEnergies = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getHP() {
        return hp;
    }

    public List<Attack> getAttacks() {
        return attacks;
    }
    
    public List<String> getAttachedEnergies() {
        return attachedEnergies;
    }

    public void takeDamage(int damage) {
        hp -= damage;
        if (hp < 0) {
            hp = 0;
        }
    }

    public boolean isKnockedOut() {
        return hp == 0;
    }

    /**
     * Heals the Pokémon by the specified amount, not exceeding maxHP.
     */
    public void heal(int amount) {
        hp += amount;
        if (hp > maxHP) {
            hp = maxHP;
        }
    }

    /**
     * Attaches an Energy card to this Pokémon.
     */
    public void attachEnergy(EnergyCard energy) {
        attachedEnergies.add(energy.getType());
    }

    /**
     * Checks if this Pokémon can use the attack at the given index by verifying
     * if the attached energies satisfy the attack's energy cost.
     */
    public boolean canUseAttack(int attackIndex) {
        if (attackIndex < 0 || attackIndex >= attacks.size()) {
            return false;
        }
        List<String> cost = attacks.get(attackIndex).getEnergyCost();
        Map<String, Integer> costCount = new HashMap<>();
        for (String energyType : cost) {
            costCount.put(energyType, costCount.getOrDefault(energyType, 0) + 1);
        }
        Map<String, Integer> energyCount = new HashMap<>();
        for (String energyType : attachedEnergies) {
            energyCount.put(energyType, energyCount.getOrDefault(energyType, 0) + 1);
        }
        for (Map.Entry<String, Integer> entry : costCount.entrySet()) {
            String reqType = entry.getKey();
            int reqCount = entry.getValue();
            if (energyCount.getOrDefault(reqType, 0) < reqCount) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks if the provided EnergyCard is proficient for this Pokémon.
     * A Pokémon accepts an Energy card if it is "Basic" or matches its type.
     */
    public boolean isEnergyProficient(EnergyCard energy) {
        return energy.getType().equalsIgnoreCase("Basic") || energy.getType().equalsIgnoreCase(this.type);
    }

    /**
     * Attacks the opponent using the specified attack index.
     * (Assumes energy cost checking has already been done.)
     */
    public int attack(Pokemon opponent, int attackIndex) {
        if (attackIndex < 0 || attackIndex >= attacks.size()) {
            System.out.println("Invalid attack index for " + name);
            return 0;
        }
        Attack chosenAttack = attacks.get(attackIndex);
        int damage = chosenAttack.getDamage();
        opponent.takeDamage(damage);
        return damage;
    }

    @Override
    public String toString() {
        return name + " [" + type + ", HP: " + hp + ", Attacks: " + attacks + ", Energies: " + attachedEnergies + "]";
    }
}
