/**
 * The TrainerCard class represents a Trainer card.
 * Trainer cards can affect the game by providing various benefits.
 */
public class TrainerCard implements Card {
    private String name;
    private String effectDescription;

    public TrainerCard(String name, String effectDescription) {
        this.name = name;
        this.effectDescription = effectDescription;
    }

    public String getName() {
        return name;
    }

    public String getEffectDescription() {
        return effectDescription;
    }

    /**
     * Applies the effect of this Trainer card to the specified player.
     * Effects:
     * - Professor's Research: Discard hand and draw 7 cards.
     * - Bill: Draw 2 cards.
     * - Lana: Heal 50 HP from the active Water type Pokémon.
     * - Gym Trainer: Draw 2 cards; if a Pokémon was knocked out last turn, draw an extra 2 cards.
     *
     * @param player the player who plays this Trainer card.
     */
    public void applyEffect(PokemonGame.Player player) {
        System.out.println("Applying effect of " + name + ": " + effectDescription);
        if(name.equals("Professor's Research")) {
            player.discardHand();
            player.drawCards(7);
        } else if(name.equals("Bill")) {
            player.drawCards(2);
        } else if(name.equals("Lana")) {
            Pokemon active = player.getActivePokemon();
            if(active != null && active.getType().equalsIgnoreCase("Water")) {
                active.heal(50);
                System.out.println(active.getName() + " is healed by 50 HP.");
            } else {
                System.out.println("No Water type Pokémon available to heal.");
            }
        } else if(name.equals("Gym Trainer")) {
            player.drawCards(2);
            if(player.hadKnockedOutLastTurn()) {
                player.drawCards(2);
            }
        } else {
            System.out.println("No defined effect for " + name);
        }
    }

    @Override
    public String toString() {
        return name + " [Effect: " + effectDescription + "]";
    }
}
